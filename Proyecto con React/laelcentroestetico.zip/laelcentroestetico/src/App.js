
import './App.css';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom'
import Navbar from './Componentes/navegacion/Navbar';
import Inicio from './Componentes/Paginas/Inicio';
import QuienesSomos from './Componentes/Paginas/QuienesSomos';
import Servicios from './Componentes/Paginas/Servicios';
import Contactos from './Componentes/Paginas/Contactos';


function App() {

  return (
    <div className="App">
      
      <Router>
        <Navbar />
        <Inicio />
      </Router>

     
    </div>
    
  );
}

export default App;
