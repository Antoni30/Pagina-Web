import React from "react";

const Inicio = ( )=>{
    return (
        <div>
            <div className="textoPrincipal1" >
                    <p >CENTRO ESTETICO LAEL TE DA LA BIENVENIDA!! </p>
            </div>        
             <div class="marquesina">
                    <marquee scrollamount="10" direction="right" >
                        <img width="450ppx" src="ImagenesProyecto/8.jpg"/>
                        <img width="400ppx"  src="ImagenesProyecto/marquesina1.gif"/>
                        <img width="450ppx" src="ImagenesProyecto/6.jpg"/>
                        <img width="400ppx" src="ImagenesProyecto/marquesina2.gif"/>
                        <img width="500ppx" src="ImagenesProyecto/3.jpg"/>
                        <img width="400ppx" src="ImagenesProyecto/marquesina3.gif"/>
                        <img width="450ppx" src="ImagenesProyecto/4.jpg"/>
                     </marquee>
             </div>
         
             <div className="textoPrincipal">
                    <p>"El esteticista integra, se dedica a hacer tratamientos de belleza, enfocados especialmente hacia la piel" </p>
            </div>  
            <div class="grid">
                    <div class="content1">MARTES Promicion 2x1 </div>
                    <div class="content2">MIERCOLES descuentos en mascarillas</div>
                    <div class="content3">JUEVES descuento en masajes</div>
                    <div class="content4">VIERNES 10% de descuento en radiofrecuencia</div> 
             </div>
            <footer class="footer">
            <div class="contenedor">
                Centro Estetico Integral LAEL &copy; 2021
            </div>
            </footer>  
        </div>
        
    )


}

export default Inicio